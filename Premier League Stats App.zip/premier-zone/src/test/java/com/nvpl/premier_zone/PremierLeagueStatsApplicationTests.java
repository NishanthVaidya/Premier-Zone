package com.nvpl.premier_zone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PremierLeagueStatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
