package com.nvpl.premier_zone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class PremierLeagueStatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PremierLeagueStatsApplication.class, args);
	}
}
